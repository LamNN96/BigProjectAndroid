package com.example.lamnn.baitaplon.activity;

import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import android.widget.ViewFlipper;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.lamnn.baitaplon.R;
import com.example.lamnn.baitaplon.adapter.MenuAdapter;
import com.example.lamnn.baitaplon.model.ChiTietHoaDon;
import com.example.lamnn.baitaplon.model.Menu;
import com.example.lamnn.baitaplon.util.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    //ViewFlipper viewFlipper;
    //    RecyclerView recyclerView;
    NavigationView navigationView;
    DrawerLayout drawerLayout;
    ListView listView;
    public static ArrayList<Menu> mangMenu;
    public static  MenuAdapter menuAdapter;
    public static ArrayList<ChiTietHoaDon> mangChiTietHD;
    public static long tongTIen =0;
    public static int idHoaDon = 0;
    int id = 0;
    String tenMenu = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        anhXa();
        ActionBar();
        ActionViewFlipper();
        //GetDuLieuMenu();
        mangMenu.add(0, new Menu(0, "Home"));
        mangMenu.add(1, new Menu(1, "Bán hàng"));
        mangMenu.add(2, new Menu(2, "Liên hệ"));
        mangMenu.add(3, new Menu(3, "Giới thiệu"));
        mangMenu.add(4, new Menu(4, "Đăng xuất"));
        getIdHoaDon();
        CatchOnListViewMenu();

    }

    private void getIdHoaDon() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest stringRequest = new StringRequest(Server.linkGetIDHoaDon, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                idHoaDon = Integer.parseInt(response) + 1;

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        requestQueue.add(stringRequest);
    }

    public static void tinhTongTien(){
        tongTIen = 0;
        for (int i = 0; i < mangChiTietHD.size(); i++){
           tongTIen = tongTIen+  mangChiTietHD.get(i).getGiatien()*mangChiTietHD.get(i).getSoluong();
        }
    }
    private void CatchOnListViewMenu() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0: {
                        Intent intent = new Intent(MainActivity.this, MainActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                    case 1: {
                        Intent intent = new Intent(MainActivity.this, TransactionActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                    case 2: {
                        Intent intent = new Intent(MainActivity.this, LienHeActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                    case 3: {
                        Intent intent = new Intent(MainActivity.this, GioiThieuActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                    case 4: {
                        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                }
            }
        });
    }

    public void GetDuLieuMenu() {
        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Server.linkMenu, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if (response != null) {
                    for(int i = 0; i< response.length(); i++){
                        try {
                            JSONObject jsonObject = response.getJSONObject(i);
                            id = jsonObject.getInt("id_menu");
                            tenMenu = jsonObject.getString("tenmenu");
                            mangMenu.add(new Menu(id, tenMenu));
                            menuAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    mangMenu.add(3, new Menu(0, "Liên Hệ"));
                    mangMenu.add(4, new Menu(0, "Thông Tin"));
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Loix", Toast.LENGTH_SHORT);
            }
        });
        requestQueue.add(jsonArrayRequest);
    }

    private void ActionViewFlipper() {

    }

    private void ActionBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(android.R.drawable.ic_menu_sort_by_size);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }

    private void anhXa() {
        toolbar = findViewById(R.id.toolbarmanhinhchinh);
//        viewFlipper = findViewById(R.id.viewflipper);
//        recyclerView = findViewById(R.id.r);
        navigationView = findViewById(R.id.navigationview);
      listView = findViewById(R.id.listviewmanhinhchinh);
        drawerLayout = findViewById(R.id.drawer);
        mangMenu = new ArrayList<>();
//        mangMenu.add(0, new Menu(0, "Home"));
        menuAdapter = new MenuAdapter(mangMenu, getApplicationContext());
        listView.setAdapter(menuAdapter);
        if(mangChiTietHD != null){

        }else {
            mangChiTietHD = new ArrayList<>();
        }
    }

    public void btnBanHang(View view) {
        Intent intent = new Intent(MainActivity.this, TransactionActivity.class);
        startActivity(intent);
    }

    public void btnGioiThieu(View view) {
        Intent intent = new Intent(MainActivity.this, GioiThieuActivity.class);
        startActivity(intent);
    }

    public void btnLienHe(View view) {
        Intent intent = new Intent(MainActivity.this, LienHeActivity.class);
        startActivity(intent);
    }

    public void btnKhoThuoc(View view) {
        Toast.makeText(MainActivity.this, "Chức năng này đang được phát triển!", Toast.LENGTH_LONG).show();
    }
}
