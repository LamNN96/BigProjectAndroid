package com.example.lamnn.baitaplon.model;

public class TaiKhoan {
    public int ID;
    public String tenDangNhap;
    public String matKhau;

    public TaiKhoan() {
    }

    public TaiKhoan(String tenDangNhap, String matKhau) {
        this.tenDangNhap = tenDangNhap;
        this.matKhau = matKhau;
    }

    public TaiKhoan(int ID, String tenDangNhap, String matKhau) {
        this.ID = ID;
        this.tenDangNhap = tenDangNhap;
        this.matKhau = matKhau;
    }
}
