package com.example.lamnn.baitaplon.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.lamnn.baitaplon.R;
import com.example.lamnn.baitaplon.model.Menu;

import java.util.ArrayList;

/**
 * Created by lamnn on 3/27/2018.
 */

public class MenuAdapter extends BaseAdapter{
    ArrayList<Menu> arrayMenu;
    Context context;

    public MenuAdapter(ArrayList<Menu> arrayMenu, Context context) {
        this.arrayMenu = arrayMenu;
        this.context = context;
    }

    @Override
    public int getCount() {
        return arrayMenu.size();
    }

    @Override
    public Object getItem(int i) {
        return arrayMenu.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    public class ViewHolder{
        TextView txtTenMenu;
        ImageView imgMenu;

    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder = null;
        if(view == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.dong_listview_menu, null);
            viewHolder.txtTenMenu = view.findViewById(R.id.textviewmenu);
            viewHolder.imgMenu = view.findViewById(R.id.imageviewmenu);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();

        }
        Menu menu = (Menu) getItem(i);
        viewHolder.txtTenMenu.setText(menu.getTenMenu());
        return view;
    }
}
