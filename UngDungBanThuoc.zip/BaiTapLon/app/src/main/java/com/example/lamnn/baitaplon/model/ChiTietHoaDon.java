package com.example.lamnn.baitaplon.model;

public class ChiTietHoaDon {
    private int id_cthd;
    private int id_hoadon;
    private int id_thuoc;

    public String getTenthuoc() {
        return tenthuoc;
    }

    public void setTenthuoc(String tenthuoc) {
        this.tenthuoc = tenthuoc;
    }

    private String tenthuoc;

    private int soluong;

    public int getSoluongtrongkho() {
        return soluongtrongkho;
    }

    public void setSoluongtrongkho(int soluongtrongkho) {
        this.soluongtrongkho = soluongtrongkho;
    }

    private int soluongtrongkho;
    private int giatien;

    public int getId_cthd() {
        return id_cthd;
    }

    public void setId_cthd(int id_cthd) {
        this.id_cthd = id_cthd;
    }

    public int getId_hoadon() {
        return id_hoadon;
    }

    public void setId_hoadon(int id_hoadon) {
        this.id_hoadon = id_hoadon;
    }

    public int getId_thuoc() {
        return id_thuoc;
    }

    public void setId_thuoc(int id_thuoc) {
        this.id_thuoc = id_thuoc;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public int getGiatien() {
        return giatien;
    }

    public void setGiatien(int giatien) {
        this.giatien = giatien;
    }

    public ChiTietHoaDon(int id_hoadon, int id_thuoc, int soluong, int giatien, String tenthuoc, int soluongtrongkho) {

        this.id_hoadon = id_hoadon;
        this.id_thuoc = id_thuoc;
        this.soluong = soluong;
        this.giatien = giatien;
        this.tenthuoc = tenthuoc;
        this.soluongtrongkho = soluongtrongkho;
    }


    public ChiTietHoaDon() {

    }
}
