package com.example.lamnn.baitaplon.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.lamnn.baitaplon.R;
import com.example.lamnn.baitaplon.activity.MainActivity;
import com.example.lamnn.baitaplon.activity.TransactionActivity;
import com.example.lamnn.baitaplon.model.ChiTietHoaDon;
import com.example.lamnn.baitaplon.model.SanPham;

import java.util.ArrayList;

public class ChonSPAdapter extends BaseAdapter {
    ArrayList<ChiTietHoaDon> sanPhamList;
    ArrayList<ChiTietHoaDon> arraySanPham;
    Context context;

    public ChonSPAdapter(ArrayList<ChiTietHoaDon> arraySanPham, Context context) {
        this.arraySanPham = arraySanPham;
        this.context = context;
//       this.sanPhamList = new ArrayList<>();
        // this.sanPhamList.addAll(this.arraySanPham);
    }

    @Override
    public int getCount() {
        return arraySanPham.size();
    }

    @Override
    public Object getItem(int i) {
        return arraySanPham.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    public class ViewHolder {
        TextView item, gia;
        Button btnTang, btnGiam;
        EditText edtSL;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder = null;
        if (view == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.dong_sp_dachon, null);
            viewHolder.item = view.findViewById(R.id.item);
            viewHolder.gia = view.findViewById(R.id.gia);
            viewHolder.btnGiam = view.findViewById(R.id.btnGiamSoLuong);
            viewHolder.btnTang = view.findViewById(R.id.btnTangSoLuong);
            viewHolder.edtSL = view.findViewById(R.id.edtSL);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();

        }
        final ChiTietHoaDon sanPham = (ChiTietHoaDon) getItem(i);
        viewHolder.item.setText(sanPham.getTenthuoc());
        String gia = sanPham.getGiatien() + " vnđ";
        viewHolder.gia.setText(gia);
        viewHolder.edtSL.setText(sanPham.getSoluong()+"");

        // viewHolder.edtSL.setText(sanPham.getTenthuoc());
        int slnhap = sanPham.getSoluong();
        int sltrongkho = sanPham.getSoluongtrongkho();
       if (slnhap>sltrongkho-1){
            viewHolder.btnTang.setVisibility(View.INVISIBLE);
            viewHolder.btnGiam.setVisibility(View.VISIBLE);
        } else if (slnhap <=1){
           viewHolder.btnGiam.setVisibility(View.INVISIBLE);
       } else if (slnhap > 1){
           viewHolder.btnTang.setVisibility(View.VISIBLE);
           viewHolder.btnGiam.setVisibility(View.VISIBLE);
       }

        final ViewHolder finalViewHolder = viewHolder;
        viewHolder.btnTang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int slMoiNhat = Integer.parseInt(finalViewHolder.edtSL.getText().toString()) + 1;
               finalViewHolder.edtSL.setText(slMoiNhat+"");
                sanPham.setSoluong(slMoiNhat);
                notifyDataSetChanged();
            }
        });
        viewHolder.btnGiam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int slMoiNhat = Integer.parseInt(finalViewHolder.edtSL.getText().toString()) -1;
               finalViewHolder.edtSL.setText(slMoiNhat+"");
                sanPham.setSoluong(slMoiNhat);
                notifyDataSetChanged();

            }
        });
        MainActivity.tinhTongTien();
        TransactionActivity.txtTongTien.setText(MainActivity.tongTIen+" vnđ");
        notifyDataSetChanged();


        return view;
    }
}
