package com.example.lamnn.baitaplon.model;

public class SanPham {
    private int id_thuoc;
    private String tenthuoc;
    private int id_danhmuc;
    private int id_donvi;
    private int gianhap;
    private int giaxuat;
    private String motasanpham;

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    private int soluong;


    public SanPham() {
    }

    public SanPham(int id_thuoc, String tenthuoc, int id_danhmuc, int id_donvi, int gianhap, int giaxuat, String motasanpham, int soluong) {
        this.id_thuoc = id_thuoc;
        this.tenthuoc = tenthuoc;
        this.id_danhmuc = id_danhmuc;
        this.id_donvi = id_donvi;
        this.gianhap = gianhap;
        this.giaxuat = giaxuat;
        this.motasanpham = motasanpham;
        this.soluong = soluong;
    }

    public SanPham(String tenthuoc, int id_danhmuc, int id_donvi, int gianhap, int giaxuat, String motasanpham, int soluong) {
        this.tenthuoc = tenthuoc;
        this.id_danhmuc = id_danhmuc;
        this.id_donvi = id_donvi;
        this.gianhap = gianhap;
        this.giaxuat = giaxuat;
        this.motasanpham = motasanpham;
        this.soluong = soluong;
    }

    public int getId_thuoc() {
        return id_thuoc;
    }

    public void setId_thuoc(int id_menu) {
        this.id_thuoc = id_thuoc;
    }

    public String getTenthuoc() {
        return tenthuoc;
    }

    public void setTenthuoc(String tenthuoc) {
        this.tenthuoc = tenthuoc;
    }

    public int getId_danhmuc() {
        return id_danhmuc;
    }

    public void setId_danhmuc(int id_danhmuc) {
        this.id_danhmuc = id_danhmuc;
    }

    public int getId_donvi() {
        return id_donvi;
    }

    public void setId_donvi(int id_donvi) {
        this.id_donvi = id_donvi;
    }

    public int getGianhap() {
        return gianhap;
    }

    public void setGianhap(int gianhap) {
        this.gianhap = gianhap;
    }

    public int getGiaxuat() {
        return giaxuat;
    }

    public void setGiaxuat(int giaxuat) {
        this.giaxuat = giaxuat;
    }

    public String getMotasanpham() {
        return motasanpham;
    }

    public void setMotasanpham(String motasanpham) {
        this.motasanpham = motasanpham;
    }
}
