package com.example.lamnn.baitaplon.model;

/**
 * Created by lamnn on 3/27/2018.
 */

public class Menu {
    public int id_menu;
    public String tenMenu;

    public Menu() {

    }

    public Menu(int id_menu, String tenMenu) {
        this.id_menu = id_menu;
        this.tenMenu = tenMenu;
    }

    public int getId_menu() {
        return id_menu;
    }

    public void setId_menu(int id_menu) {
        this.id_menu = id_menu;
    }

    public String getTenMenu() {
        return tenMenu;
    }

    public void setTenMenu(String tenMenu) {
        this.tenMenu = tenMenu;
    }
}
