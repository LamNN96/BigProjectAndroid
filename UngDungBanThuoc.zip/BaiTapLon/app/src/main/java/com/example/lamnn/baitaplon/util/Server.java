package com.example.lamnn.baitaplon.util;

/**
 * Created by lamnn on 3/27/2018.
 */

public class Server {
  public static String localhost = "10.1.45.198";
//  public static String localhost = "192.168.100.15";
  public static String linkMenu= "http://"+localhost +"/server/getmenu.php";
  public static String linkSP= "http://"+localhost +"/server/getsp.php";
  public static String linkPostHoaDon= "http://"+localhost +"/server/posthoadon.php";
  public static String linkPostCTHD= "http://"+localhost +"/server/postchitiethoadon.php";
  public static String linkGetIDHoaDon= "http://"+localhost +"/server/getIdHoaDon.php";
  public static String dangnhap = "http://"+localhost +"/server/dangnhap.php";
//    public static String linkMenu= "http://localhost/server/getmenu.php";


}
