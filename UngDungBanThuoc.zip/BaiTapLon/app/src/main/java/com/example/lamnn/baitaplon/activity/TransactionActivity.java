package com.example.lamnn.baitaplon.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.lamnn.baitaplon.R;
import com.example.lamnn.baitaplon.adapter.ChonSPAdapter;
import com.example.lamnn.baitaplon.adapter.MenuAdapter;
import com.example.lamnn.baitaplon.adapter.SearchAdapter;
import com.example.lamnn.baitaplon.model.ChiTietHoaDon;
import com.example.lamnn.baitaplon.model.Menu;
import com.example.lamnn.baitaplon.model.SanPham;
import com.example.lamnn.baitaplon.util.Server;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.sql.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.MissingFormatArgumentException;

import static com.example.lamnn.baitaplon.activity.MainActivity.mangMenu;

public class TransactionActivity extends AppCompatActivity implements SearchView.OnQueryTextListener {
    Toolbar toolbar;
    NavigationView navigationView;
    DrawerLayout drawerLayout;
    ListView listView;

    SearchView searchView;
    ListView listSPDaChon;
    private int id_thuoc;
    private String tenthuoc;
    private int id_danhmuc;
    private int id_donvi;
    private int gianhap;
    private int giaxuat;
    private int soluong;
    private String motasanpham;
    ListView lvSearchResult;
    public ArrayList<SanPham> mangSP;
    ArrayList<SanPham> mangSPSaoChep;
    ArrayList<SanPham> mangSPDaChon;
    public static TextView txtTongTien;

    SearchAdapter searchAdapter;
    ChonSPAdapter spDaChonAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction);
        mangSP = new ArrayList<>();
        mangSPSaoChep = new ArrayList<>();
        mangSPDaChon = new ArrayList<>();
        lvSearchResult = findViewById(R.id.lvSearchResult);
        searchView = findViewById(R.id.svSanPham);
        txtTongTien = findViewById(R.id.txtTongTien);
        listSPDaChon = findViewById(R.id.lvSpDaChon);
        searchView.setFocusable(true);
        searchView.setIconified(false);
        searchView.requestFocusFromTouch();
        searchView.setOnQueryTextListener(this);

        searchAdapter = new SearchAdapter(mangSP, getApplicationContext());
        spDaChonAdapter = new ChonSPAdapter(MainActivity.mangChiTietHD, getApplicationContext());

        lvSearchResult.setAdapter(searchAdapter);
        listSPDaChon.setAdapter(spDaChonAdapter);

        toolbar = findViewById(R.id.toolbarmanhinhchinh);
//        viewFlipper = findViewById(R.id.viewflipper);
//        recyclerView = findViewById(R.id.r);
        navigationView = findViewById(R.id.navigationview);
        listView = findViewById(R.id.listviewmanhinhchinh);
        drawerLayout = findViewById(R.id.drawer);
        listView.setAdapter(MainActivity.menuAdapter);
        ActionBar();
        CatchOnListViewMenu();
        GetDuLieuSanPham();
        CatchOnSearchView();
        CatchOnListSelected();


    }

    private void CatchOnListSelected() {
        listSPDaChon.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(TransactionActivity.this);
                builder.setTitle("Xác nhận xóa sản phẩm đã chọn");
                builder.setMessage("Bạn có chắc muốn xóa sản phẩm này?");
                builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MainActivity.mangChiTietHD.remove(position);
                        MainActivity.tinhTongTien();

                        TransactionActivity.txtTongTien.setText(MainActivity.tongTIen + " vnđ");
                        spDaChonAdapter.notifyDataSetChanged();
                    }
                });
                builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        spDaChonAdapter.notifyDataSetChanged();
                    }
                });
                builder.show();
                return true;
            }
        });
    }
    private void ActionBar() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationIcon(android.R.drawable.ic_menu_sort_by_size);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }

    private void CatchOnListViewMenu() {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0: {
                        Intent intent = new Intent(TransactionActivity.this, MainActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                    case 1: {
//                        Intent intent = new Intent(TransactionActivity.this, TransactionActivity.class);
//                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                    case 2: {
                        Intent intent = new Intent(TransactionActivity.this, LienHeActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                    case 3: {
                        Intent intent = new Intent(TransactionActivity.this, GioiThieuActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                    case 4: {
                        Intent intent = new Intent(TransactionActivity.this, LoginActivity.class);
                        startActivity(intent);
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    }
                }
            }
        });
    }
    private void CatchOnSearchView() {
        lvSearchResult.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(mangSP.get(i).getSoluong() <= 0) {
                    Toast.makeText(getBaseContext(), "Loại thuốc này trong kho đã hết!", Toast.LENGTH_LONG).show();
                } else {
                    int idTrung = 0;
                    if (MainActivity.mangChiTietHD.size() > 0) {
                        boolean flag = false;
                        for (int index = 0; index < MainActivity.mangChiTietHD.size(); index++) {
                            if (MainActivity.mangChiTietHD.get(index).getId_thuoc() == mangSP.get(i).getId_thuoc()) {
                                flag = true;
                                idTrung = MainActivity.mangChiTietHD.get(index).getId_thuoc();
                            } else flag = false;

                        }
                        if (flag == true) {
                            for (int j = 0; j < MainActivity.mangChiTietHD.size(); j++) {
                                if (MainActivity.mangChiTietHD.get(j).getId_thuoc() == idTrung) {
                                    MainActivity.mangChiTietHD.get(j).setSoluong(MainActivity.mangChiTietHD.get(j).getSoluong() + 1);
                                }
                            }
//                        MainActivity.mangChiTietHD.get(indexTrungMangCTHD).setSoluong(MainActivity.mangChiTietHD.get(indexTrungMangCTHD).getSoluong() + 1);
                        } else {
                            ChiTietHoaDon sanPham = new ChiTietHoaDon(1, mangSP.get(i).getId_thuoc(), 1, mangSP.get(i).getGiaxuat(), mangSP.get(i).getTenthuoc(), mangSP.get(i).getSoluong());
                            MainActivity.mangChiTietHD.add(sanPham);
                        }


                    } else {
                        ChiTietHoaDon sanPham = new ChiTietHoaDon(1, mangSP.get(i).getId_thuoc(), 1, mangSP.get(i).getGiaxuat(), mangSP.get(i).getTenthuoc(), mangSP.get(i).getSoluong());
                        MainActivity.mangChiTietHD.add(sanPham);
                    }

                    spDaChonAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void GetDuLieuSanPham() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Server.linkSP, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                if (response != null) {
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            JSONObject jsonObject = response.getJSONObject(i);
                            id_thuoc = jsonObject.getInt("id_thuoc");
                            id_danhmuc = jsonObject.getInt("id_danhmuc");
                            id_donvi = jsonObject.getInt("id_donvi");
                            gianhap = jsonObject.getInt("gianhap");
                            giaxuat = jsonObject.getInt("giaxuat");
                            tenthuoc = jsonObject.getString("tenthuoc");
                            motasanpham = jsonObject.getString("motasanpham");
                            soluong = jsonObject.getInt("soluong");


                            mangSP.add(new SanPham(id_thuoc, tenthuoc, id_danhmuc, id_donvi, gianhap, giaxuat, motasanpham, soluong));
                            mangSPSaoChep.add(new SanPham(id_thuoc, tenthuoc, id_danhmuc, id_donvi, gianhap, giaxuat, motasanpham, soluong));
                            searchAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "Loix", Toast.LENGTH_SHORT);
            }
        });
        requestQueue.add(jsonArrayRequest);
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {
        String text = s;
        searchAdapter.filter(mangSPSaoChep, text);
        return false;
    }

    public void banHang(View view) {
        //đẩy dữ liệu lên server
        if (MainActivity.mangChiTietHD.size() == 0) {

            Toast.makeText(this, "Danh sách cần thanh toán đang trống!", Toast.LENGTH_LONG).show();
        } else {
            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            StringRequest stringRequest = new StringRequest(Request.Method.POST, Server.linkPostHoaDon, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
//                    Log.d("mahd", response);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> stringStringHashMap = new HashMap<>();
                    stringStringHashMap.put("tongsotien", String.valueOf(MainActivity.tongTIen));
                    return stringStringHashMap;
                }
            };
            StringRequest stringRequestUpCTHD = new StringRequest(Request.Method.POST, Server.linkPostCTHD, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("upchi", response);
                    if(response.equalsIgnoreCase("1")){
                        Log.d("upchi", response);
                        Toast.makeText(TransactionActivity.this, "Thanh toán thành công!", Toast.LENGTH_LONG).show();
                        MainActivity.mangChiTietHD.clear();
                        txtTongTien.setText("");
                        spDaChonAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(TransactionActivity.this, "Lỗi!", Toast.LENGTH_LONG).show();

                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    JSONArray jsonArray = new JSONArray();
                    for (int i = 0; i < MainActivity.mangChiTietHD.size(); i++){
                        JSONObject jsonObject = new JSONObject();
                        try {
                            jsonObject.put("id_hoadon", MainActivity.idHoaDon);
                            jsonObject.put("id_thuoc", MainActivity.mangChiTietHD.get(i).getId_thuoc());
                            jsonObject.put("soluong", MainActivity.mangChiTietHD.get(i).getSoluong());
                            jsonObject.put("giatien", MainActivity.mangChiTietHD.get(i).getGiatien());
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        jsonArray.put(jsonObject);
                    }

                    HashMap<String, String> stringStringHashMap = new HashMap<>();
                    stringStringHashMap.put("json", jsonArray.toString());

                        return stringStringHashMap;
                }
            };
            requestQueue.add(stringRequest);
            requestQueue.add(stringRequestUpCTHD);



        }


    }
}
