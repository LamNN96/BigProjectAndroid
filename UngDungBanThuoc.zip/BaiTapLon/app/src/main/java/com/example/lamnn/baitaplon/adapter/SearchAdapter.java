package com.example.lamnn.baitaplon.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.lamnn.baitaplon.R;
import com.example.lamnn.baitaplon.model.Menu;
import com.example.lamnn.baitaplon.model.SanPham;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public class SearchAdapter extends BaseAdapter {

    ArrayList<SanPham> sanPhamList;
    ArrayList<SanPham> arraySanPham;
    Context context;

    public SearchAdapter(ArrayList<SanPham> arraySanPham, Context context) {
        this.arraySanPham = arraySanPham;
        this.context = context;
//       this.sanPhamList = new ArrayList<>();
       // this.sanPhamList.addAll(this.arraySanPham);
    }

    @Override
    public int getCount() {
        return arraySanPham.size();
    }

    @Override
    public Object getItem(int i) {
        return arraySanPham.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    public class ViewHolder {
        TextView item;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder = null;
        if (view == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.dong_searchview, null);
            viewHolder.item = view.findViewById(R.id.item);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();

        }
        SanPham sanPham = (SanPham) getItem(i);
        viewHolder.item.setText(sanPham.getTenthuoc());
        return view;
    }

    // Filter Class
    public void filter(ArrayList<SanPham> arraySanPhamArgument,String charText) {
        sanPhamList = new ArrayList<>();
        sanPhamList.addAll(arraySanPhamArgument);

        charText = charText.toLowerCase(Locale.getDefault());
        arraySanPham.clear();
        if (charText.length() == 0) {
            arraySanPham.addAll(sanPhamList);
        } else {
            for (SanPham sp : sanPhamList) {
                if (sp.getTenthuoc().toLowerCase(Locale.getDefault()).contains(charText)) {
                    arraySanPham.add(sp);
                }
            }
        }
        notifyDataSetChanged();

    }
}
